<?php
// Establish a connection to your database
$server = "localhost";
$user = "root";
$password = "";
$dbname = "fashions";
$conn = new mysqli($server, $user, $password,$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve user input from the registration form

if (isset($_POST['username'],$_POST['password'] )) {
    // Process the registration data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // User exists, check password
        $row = $result->fetch_assoc();
        $hashedPassword = $row['password'];

        // Use password_verify to check the password against the hashed one
        if (password_verify($password, $hashedPassword)) {
            echo "Login successful!";
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "User not registered.";
    }

    $stmt->close();
} else {
    echo "Incomplete login data received.";
}

$conn->close();
?>